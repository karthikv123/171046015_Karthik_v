import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import matplotlib

df = pd.read_csv('13.csv', names=['TERMS', 'COUNT'])
df1 = df.dropna(how='all')
df2 = df1.head(5)
print df2

row=df2.ix[:,0]

ax = df2.plot(kind='bar', title ="VARIATION IN DISEASE COUNT", legend=True, fontsize=12,color='r')
ax.set_xlabel("DISEASES", fontsize=12)
ax.xaxis.set_ticklabels(row)
ax.set_ylabel("COUNT", fontsize=12)

plt.show()
