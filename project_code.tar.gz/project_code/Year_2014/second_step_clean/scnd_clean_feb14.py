import sys
f=open("fullcleandec.txt",'w')
sys.stdout=f
for line in open("cleanfeb.txt"):
	if "cancer" in line or "tobacco" in line or "medical" in line or "treatment" in line or "hospital" in line \
    or "health" in line or "dengue" in line or "disease" in line or "arthritis" in line or "asthma" in line \
    or "chronic" in line or "contagious" in line or "diabetes" in line or "emergency" in line or "fever" in line \
    or "h1n1" in line or "hayfever" in line or "hives" in line or "heart attack" in line or "infected" in line \
    or "lung" in line or "poisoning" in line or "tumor" in line or "ulcer" in line or "viral" in line :
		print line 
f.close()




