import nltk
import re
from collections import Counter
from nltk.tokenize import sent_tokenize, word_tokenize
from string import punctuation
from nltk.corpus import stopwords

from nltk.collocations import BigramCollocationFinder

import sys  

reload(sys)  
sys.setdefaultencoding('utf8')

response = open ("dectest.out", "r")
raw = response.read()
#print raw

raw1 = (word_tokenize(raw))
#print raw1

def remove_tokens(raw1,remove_tokens):
	return [raw1 for raw1 in raw1 if raw1 not in remove_tokens]
removed = remove_tokens(raw1,punctuation)
#print removed

def lowercase(removed):
	return [removed.lower() for removed in removed]
normalized = lowercase(removed)
#print normalized

stopWords = set(stopwords.words('english'))
#words = word_tokenize(normalized)
wordsFiltered = []
for w in normalized:
	if w not in stopWords:
    	 wordsFiltered.append(w) 
#print(wordsFiltered)

def remove_fragments(wordsFiltered):
	return [wordsFiltered for wordsFiltered in wordsFiltered if "\xe2" not in wordsFiltered]
removed_frag = remove_fragments(wordsFiltered)
#print removed_frag

counts = Counter(removed_frag)
sorted_counts= sorted(counts.items(),key=lambda count:count[1],reverse=True)
#print sorted_counts
#for i in sorted_counts:
#	print i

finder=BigramCollocationFinder.from_words(sorted_counts)
bigram_measures = nltk.collocations.BigramAssocMeasures()
rawfreq = finder.score_ngrams(bigram_measures.raw_freq)
#for i in rawfreq:
#	print i

rawfreq = finder.score_ngrams(bigram_measures.likelihood_ratio)
#for i in rawfreq:
#	print i

import sys
f = open("cleandec.txt", 'w')
sys.stdout = f
for i in sorted_counts:
	print i
f.close()
